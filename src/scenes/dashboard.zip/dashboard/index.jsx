import './index.css'
import AreaCharts from './dash-components/AreaChart'
import mg from './mg.png'

import Progress from './dash-components/Progress'
import team from './team.png'
import project from './project.png'
import cadre from './profilecadre.png';
import RotatingText from '../../components/Reactbit/RotatingText ';
const Index = () => {
  return (
    <div className='maindash'>
      <div className="left">
       
        <div className="welcomeback">
          <div className='msg'>
             <p className='ww'>
          <span className="gg">Welcome</span>back!
         
        </p>
        <span className='name'>
          -Hamzaoui Mouhib-
        </span>
         <span>
            Your career management dashboard is ready to empower your journey. Let's make progress together!
          </span>
          </div>
          
          <div className='imgs'>
             
          <img className='mg' src={mg} alt="" />
         
          
        </div>  
        </div>
        <div className='chartss'>
        <div className='peecharts'>
          <p>Formation actuelle</p>
          <AreaCharts></AreaCharts>
        </div>
        <div className="progress">
          <p>Progress</p>
          <div className='prog'>
          <Progress></Progress>
          </div>
        </div>
        <div className='team2'>
        <div className='teams'>
        <div className="team">
         <div className='imgsss'>
          <img  className='membre' src={team} alt="" />
          </div>
          <div className='stats'>
            <p>
              Team
            </p>
            <span>
              5
            </span>
          </div>
          
        </div>

        </div>
         <div className='teams'>
        <div className="team">
         <div className='imgsss'>
          <img  className='membre' src={project} alt="" />
          </div>
          <div className='stats2'>
            <p >
              Certificats
            </p>
            <span>
              +10
            </span>
          </div>
          
        </div>

        </div>
        </div>
      
        
      </div>
     <p style={{ fontSize: 20 }}>
  Formation
</p>
<div className='formations'>

     <div className="formation1">
    <div className="photo">
      <div className='lgf' >
      <img className='form' src="https://img.icons8.com/?size=512&id=78295&format=png" alt="" />
     
      </div>
       <p>Symfony</p>
    </div>
    <p>Les certifications Symfony valorisent vos compétences et dynamisent votre carrière.

</p>
  </div>
    <div className="formation1">
    <div className="photo">
      <div className='lgf' >
      <img className='form' src="https://cdn-icons-png.freepik.com/256/11674/11674239.png?semt=ais_hybrid" alt="" />
     
      </div>
       <p>React-js</p>
    </div>
    <p>Les certifications React valorisent vos compétences et boostent votre carrière.

</p>
  </div>
    <div className="formation1">
    <div className="photo">
      <div className='lgf' >
      <img className='form' src="https://cdn-icons-png.flaticon.com/512/919/919852.png" alt="" />
     
      </div>
       <p>Symfony</p>
    </div>
    <p>Les certifications Python renforcent vos compétences et dynamisent votre carrière.

</p>
  </div>
</div>

      </div>
      <div className="righ">
        <div className='Logo'>
           <RotatingText />
        </div>
        <div className='name2'>
          
          <img className='cadre' src={cadre} alt="" />
          <img className='prpicture' src="https://scontent.ftun1-2.fna.fbcdn.net/v/t39.30808-6/466392131_2380393522299461_77210064096490724_n.jpg?_nc_cat=107&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=ESR6yfsdV7kQ7kNvwGhFlei&_nc_oc=Adkq6mcBLRdbpb9bZGl27K09UGuvsDmwUnbokyqxqPBPh6Ucb1Ms0cPKhX04zqnd7GI&_nc_zt=23&_nc_ht=scontent.ftun1-2.fna&_nc_gid=PBwis4sYpQu6u7Ijt4iAGg&oh=00_AfIG4TR-4ZvYB_CywH7gYZq6i17t_ah2YTi2hiE9KwH2rg&oe=682AF54A" alt="" />
         
        </div>
         <div className='firstlast'>
            <p>Hamzaoui Mouhib</p>
            <span>Position : </span>
             <button className="pp1btn">
    <span className="pp1btn-text-one">Edit Profile</span>
    <span className="pp1btn-text-two">Great!</span>
</button>


          </div>
       <div className='onlineteam'>
       

       </div>
      </div>
    </div>
  )
}

export default Index